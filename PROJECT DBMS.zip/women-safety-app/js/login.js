/* =====================================================
   SAFEHER LOGIN ANIMATION
===================================================== */

const hero =
    document.getElementById("hero");

const shield =
    document.getElementById("shield");

const energy =
    document.getElementById("energy");

const loginCard =
    document.getElementById("loginCard");


/* =====================================================
   CREATE PARTICLES
===================================================== */

function createParticles() {

    for (let i = 0; i < 90; i++) {

        const particle =
            document.createElement("span");

        particle.style.position =
            "absolute";

        particle.style.width =
            Math.random() * 4 + 1 + "px";

        particle.style.height =
            particle.style.width;

        particle.style.borderRadius =
            "50%";

        particle.style.background =
            i % 3 === 0
                ? "#ff3d7f"
                : "#ffffff";

        particle.style.left =
            Math.random() * 100 + "%";

        particle.style.top =
            Math.random() * 100 + "%";

        particle.style.opacity =
            Math.random() * .5;

        particle.style.boxShadow =
            "0 0 8px rgba(255,60,130,.7)";

        particle.style.animation =
            `floatParticle ${
                3 + Math.random() * 6
            }s ease-in-out infinite`;

        particle.style.animationDelay =
            Math.random() * 4 + "s";

        document
            .querySelector(".particles")
            .appendChild(particle);

    }

}


const particleStyle =
document.createElement("style");

particleStyle.innerHTML = `

@keyframes floatParticle {

    0%,100% {

        transform:
            translate(0,0);

        opacity:.15;

    }

    50% {

        transform:
            translate(
                ${Math.random() * 40 - 20}px,
                -30px
            );

        opacity:.8;

    }

}

`;

document.head.appendChild(particleStyle);

createParticles();


/* =====================================================
   MAIN INTRO ANIMATION
===================================================== */

window.addEventListener(
    "load",
    () => {

        /*
            Timeline

            0s    Scene appears
            1.2s  Shield intensifies
            2.2s  Energy begins
            2.8s  Hero disappears
            3.3s  Login appears
        */


        setTimeout(() => {

            shield.style.transform =
                "scale(1.15)";

            shield.style.filter =
                "drop-shadow(0 0 35px #ff3d7f)";

        }, 1200);


        setTimeout(() => {

            energy.classList.add(
                "explode"
            );

        }, 2200);


        setTimeout(() => {

            hero.classList.add(
                "hide"
            );

        }, 2500);


        setTimeout(() => {

            loginCard.classList.add(
                "show"
            );

        }, 3000);

    }
);


/* =====================================================
   PASSWORD TOGGLE
===================================================== */

const password =
    document.getElementById(
        "password"
    );

const togglePassword =
    document.getElementById(
        "togglePassword"
    );


togglePassword.addEventListener(
    "click",
    () => {

        if (
            password.type ===
            "password"
        ) {

            password.type =
                "text";

            togglePassword.textContent =
                "◌";

        } else {

            password.type =
                "password";

            togglePassword.textContent =
                "◉";

        }

    }
);


/* =====================================================
   LOGIN
===================================================== */

const loginForm =
    document.getElementById(
        "loginForm"
    );

const message =
    document.getElementById(
        "message"
    );

const loginBtn =
    document.getElementById(
        "loginBtn"
    );


loginForm.addEventListener(
    "submit",
    async (event) => {

        event.preventDefault();


        const email =
            document
                .getElementById("email")
                .value
                .trim();

        const passwordValue =
            password.value
                .trim();


        if (!email ||
            !passwordValue) {

            message.textContent =
                "Please enter your login details.";

            return;

        }


        loginBtn.disabled =
            true;

        loginBtn.querySelector(
            "span"
        ).textContent =
            "Authenticating...";


        /*
            FIREBASE AUTHENTICATION
            WILL BE CONNECTED HERE.

            Later:

            signInWithEmailAndPassword(
                auth,
                email,
                passwordValue
            )
        */


        setTimeout(() => {

            loginBtn.disabled =
                false;

            loginBtn.querySelector(
                "span"
            ).textContent =
                "Sign in securely";

            message.style.color =
                "#8d93a2";

            message.textContent =
                "Firebase authentication will be connected next.";

        }, 1200);

    }
);


/* =====================================================
   FORGOT PASSWORD
===================================================== */

document
    .getElementById("forgot")
    .addEventListener(
        "click",
        () => {

            const email =
                document
                    .getElementById("email")
                    .value
                    .trim();


            if (!email) {

                message.textContent =
                    "Enter your email first.";

                return;

            }


            message.style.color =
                "#8d93a2";

            message.textContent =
                "Password reset will be connected to Firebase.";

        }
    );


/* =====================================================
   SIGN UP
===================================================== */

document
    .getElementById("signup")
    .addEventListener(
        "click",
        () => {

            message.style.color =
                "#8d93a2";

            message.textContent =
                "Registration page coming next.";

        }
    );