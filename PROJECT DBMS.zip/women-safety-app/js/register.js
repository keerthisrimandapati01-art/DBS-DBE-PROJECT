// ==========================================
// SAFEHER - REGISTER
// ==========================================

import {
    initializeApp
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";

import {
    getAuth,
    createUserWithEmailAndPassword,
    sendEmailVerification
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";


// ==========================================
// FIREBASE CONFIG
// ==========================================

const firebaseConfig = {
    apiKey: "AIzaSyCQ4W4DiWr--x9xr2sigT2huMpNdyWR5Ors",
    authDomain: "safeher-40703.firebaseapp.com",
    projectId: "safeher-40703",
    storageBucket: "safeher-40703.firebasestorage.app",
    messagingSenderId: "1042565835984",
    appId: "1:1042565835984:web:91cef9cd03ef9989cfc2d5"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);


// ==========================================
// DOM ELEMENTS
// ==========================================

const registerForm = document.getElementById("registerForm");


// ==========================================
// REGISTER
// ==========================================

if (registerForm) {

    registerForm.addEventListener("submit", async (event) => {

        event.preventDefault();

        try {

            // ------------------------------------------
            // GET FORM VALUES
            // ------------------------------------------

            const firstName =
                document.getElementById("firstName")?.value.trim();

            const lastName =
                document.getElementById("lastName")?.value.trim();

            const email =
                document.getElementById("email")?.value.trim();

            const phone =
                document.getElementById("phone")?.value.trim();

            const password =
                document.getElementById("password")?.value;

            const confirmPassword =
                document.getElementById("confirmPassword")?.value;


            // ------------------------------------------
            // VALIDATION
            // ------------------------------------------

            if (!firstName || !lastName) {
                alert("Please enter your full name.");
                return;
            }

            if (!email) {
                alert("Please enter your email address.");
                return;
            }

            if (!phone) {
                alert("Please enter your phone number.");
                return;
            }

            const cleanPhone = phone.replace(/\D/g, "");

            if (!/^[6-9]\d{9}$/.test(cleanPhone)) {
                alert("Please enter a valid 10-digit Indian mobile number.");
                return;
            }

            if (!password) {
                alert("Please enter a password.");
                return;
            }

            if (password.length < 6) {
                alert("Password must contain at least 6 characters.");
                return;
            }

            if (password !== confirmPassword) {
                alert("Passwords do not match.");
                return;
            }


            // ------------------------------------------
            // CREATE FIREBASE ACCOUNT
            // ------------------------------------------

            const userCredential =
                await createUserWithEmailAndPassword(
                    auth,
                    email,
                    password
                );

            const user = userCredential.user;


            // ------------------------------------------
            // SAVE USER INFORMATION LOCALLY
            // ------------------------------------------

            const fullName = `${firstName} ${lastName}`;

            localStorage.setItem(
                "safeher_name",
                fullName
            );

            localStorage.setItem(
                "safeher_email",
                email
            );

            localStorage.setItem(
                "safeher_phone",
                cleanPhone
            );

            localStorage.setItem(
                "safeher_uid",
                user.uid
            );


            // ------------------------------------------
            // SEND FIREBASE EMAIL VERIFICATION
            // ------------------------------------------

            await sendEmailVerification(user);


            // ------------------------------------------
            // SUCCESS
            // ------------------------------------------

            alert(
                "Account created successfully!\n\n" +
                "A verification email has been sent to:\n" +
                email +
                "\n\n" +
                "Please verify your email to continue."
            );


            // ------------------------------------------
            // GO TO EMAIL VERIFICATION PAGE
            // ------------------------------------------

            window.location.href = "verify-email.html";


        } catch (error) {

            console.error("Registration Error:", error);

            let message = "Registration failed.";

            switch (error.code) {

                case "auth/email-already-in-use":
                    message =
                        "This email is already registered.";
                    break;

                case "auth/invalid-email":
                    message =
                        "Please enter a valid email address.";
                    break;

                case "auth/weak-password":
                    message =
                        "Password is too weak.";
                    break;

                case "auth/network-request-failed":
                    message =
                        "Network error. Please check your internet connection.";
                    break;

                default:
                    message =
                        error.message || "Registration failed.";
            }

            alert(message);
        }

    });

}