import { auth, db } from "./firebase.js";

import {
    onAuthStateChanged,
    signOut
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

import {
    doc,
    getDoc,
    setDoc,
    collection,
    addDoc,
    getDocs,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";


const API = "http://localhost:5000";

let currentUser = null;

let currentLocation = null;

let map = null;

let marker = null;

let accuracyCircle = null;

let watchId = null;

let activeSOS = null;

let routeLayer = null;

let audioRecorder = null;

let audioChunks = [];

let cameraStream = null;


const $ = id =>
    document.getElementById(id);


// ======================================================
// MODALS
// ======================================================

function openModal(id) {

    $("backdrop")?.classList.add("open");

    $(id)?.classList.add("open");

}


function closeModals() {

    $("backdrop")?.classList.remove("open");

    document
        .querySelectorAll(".modal")
        .forEach(modal => {

            modal.classList.remove("open");

        });


    if (cameraStream) {

        cameraStream
            .getTracks()
            .forEach(track => track.stop());

        cameraStream = null;

    }

}


$("backdrop")?.addEventListener(
    "click",
    closeModals
);


document
    .querySelectorAll("[data-close]")
    .forEach(button => {

        button.addEventListener(
            "click",
            closeModals
        );

    });


// ======================================================
// PROFILE MENU
// ======================================================

$("profileBtn")?.addEventListener(
    "click",
    event => {

        event.stopPropagation();

        $("menu")?.classList.toggle("open");

    }
);


document.addEventListener(
    "click",
    () => {

        $("menu")?.classList.remove("open");

    }
);


$("profile")?.addEventListener(
    "click",
    () => {

        openModal("profileModal");

    }
);


$("settings")?.addEventListener(
    "click",
    () => {

        openModal("settingsModal");

    }
);


$("logout")?.addEventListener(
    "click",
    async () => {

        await signOut(auth);

        localStorage.removeItem(
            "safeher_phone_verified"
        );

        location.href =
            "../index.html";

    }
);


// ======================================================
// QUICK ACTIONS
// ======================================================

$("qguard")?.addEventListener(
    "click",
    () => openModal("guardianModal")
);


$("qprofile")?.addEventListener(
    "click",
    () => openModal("profileModal")
);


$("qsettings")?.addEventListener(
    "click",
    () => openModal("settingsModal")
);


$("qEvidence")?.addEventListener(
    "click",
    () => openModal("evidenceModal")
);


$("add")?.addEventListener(
    "click",
    () => openModal("guardianModal")
);


// ======================================================
// MAP
// ======================================================

function initMap() {

    map =
        L.map("map")
        .setView(
            [17.385, 78.4867],
            13
        );


    L.tileLayer(
        "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
        {
            attribution:
                "© OpenStreetMap contributors"
        }
    ).addTo(map);

}


// ======================================================
// GPS
// ======================================================

function startTracking() {

    if (
        watchId !== null ||
        !navigator.geolocation
    ) {

        return;

    }


    watchId =
        navigator.geolocation.watchPosition(

            position => {

                const coords =
                    position.coords;


                currentLocation = {

                    latitude:
                        coords.latitude,

                    longitude:
                        coords.longitude,

                    accuracy:
                        coords.accuracy,

                    speed:
                        coords.speed

                };


                $("gps").textContent =
                    `±${Math.round(
                        coords.accuracy
                    )}m accuracy`;


                $("loc").textContent =
                    "Live";


                const latlng = [

                    coords.latitude,

                    coords.longitude

                ];


                if (!marker) {

                    marker =
                        L.marker(latlng)
                        .addTo(map)
                        .bindPopup(
                            "📍 You are here"
                        );


                    accuracyCircle =
                        L.circle(
                            latlng,
                            {
                                radius:
                                    coords.accuracy
                            }
                        )
                        .addTo(map);


                    map.setView(
                        latlng,
                        16
                    );

                } else {

                    marker.setLatLng(
                        latlng
                    );


                    accuracyCircle
                        .setLatLng(latlng)
                        .setRadius(
                            coords.accuracy
                        );

                }


                updateRisk();


                // ----------------------------------
                // REAL-TIME SOS LOCATION UPDATE
                // ----------------------------------

                if (activeSOS) {

                    updateSOSLocation(
                        coords
                    );

                }

            },

            error => {

                console.error(
                    "GPS ERROR:",
                    error
                );


                $("gps").textContent =
                    "GPS permission required";


                $("loc").textContent =
                    "Unavailable";

            },

            {

                enableHighAccuracy: true,

                timeout: 10000,

                maximumAge: 3000

            }

        );

}


// ======================================================
// SEND LIVE SOS LOCATION
// ======================================================

async function updateSOSLocation(coords) {

    if (!activeSOS) {
        return;
    }


    try {

        await fetch(
            `${API}/api/sos/update`,
            {

                method: "POST",

                headers: {
                    "Content-Type":
                        "application/json"
                },

                body:
                    JSON.stringify({

                        sessionId:
                            activeSOS,

                        latitude:
                            coords.latitude,

                        longitude:
                            coords.longitude,

                        accuracy:
                            coords.accuracy,

                        speed:
                            coords.speed

                    })

            }
        );

    } catch (error) {

        console.error(
            "SOS location update error:",
            error
        );

    }

}


// ======================================================
// RISK
// ======================================================

function updateRisk() {

    if (!currentLocation) {
        return;
    }


    let risk = 10;


    const hour =
        new Date().getHours();


    if (
        hour >= 22 ||
        hour < 5
    ) {

        risk += 30;

    }


    if (
        currentLocation.accuracy > 100
    ) {

        risk += 15;

    }


    if (
        currentLocation.speed != null &&
        currentLocation.speed > 13.9
    ) {

        risk += 10;

    }


    risk =
        Math.min(
            95,
            risk
        );


    const score =
        document.querySelector(
            ".score"
        );


    if (score) {

        score.textContent =
            `${risk}%`;

    }


    const meter =
        document.querySelector(
            ".meter i"
        );


    if (meter) {

        meter.style.width =
            `${risk}%`;

    }


    const label =
        document.querySelector(
            ".metric b"
        );


    if (label) {

        label.textContent =
            risk < 35
                ? "Low"
                : risk < 65
                    ? "Moderate"
                    : "High";

    }

}


// ======================================================
// PROFILE
// ======================================================

async function loadProfile() {

    if (!currentUser) {
        return;
    }


    const snapshot =
        await getDoc(
            doc(
                db,
                "users",
                currentUser.uid
            )
        );


    const data =
        snapshot.exists()
            ? snapshot.data()
            : {};


    const name =
        data.name ||
        localStorage.getItem(
            "safeher_name"
        ) ||
        "there";


    $("name").textContent =
        name.split(" ")[0];


    $("pname").value =
        name;


    $("pemail").value =
        currentUser.email;


    $("pphone").value =
        data.phone ||
        localStorage.getItem(
            "safeher_phone"
        ) ||
        "";


    await loadGuardians();

}


// ======================================================
// GUARDIANS
// ======================================================

async function getGuardians() {

    if (!currentUser) {
        return [];
    }


    const snapshot =
        await getDocs(
            collection(
                db,
                "users",
                currentUser.uid,
                "guardians"
            )
        );


    return snapshot.docs.map(
        snapshotDoc =>
            snapshotDoc.data()
    );

}


async function loadGuardians() {

    const container =
        $("guardians");


    if (!container) {
        return;
    }


    container.innerHTML =
        "";


    const guardians =
        await getGuardians();


    if (!guardians.length) {

        container.innerHTML = `
            <div class="empty">
                No guardians added yet.
                <br>
                <small>
                    Add someone you trust.
                </small>
            </div>
        `;

        return;

    }


    guardians.forEach(
        guardian => {

            const element =
                document.createElement(
                    "div"
                );


            element.className =
                "guardian";


            const phone =
                String(
                    guardian.phone || ""
                )
                .replace(
                    /\D/g,
                    ""
                );


            element.innerHTML = `

                <div class="guardian-avatar">
                    ${(guardian.name || "G")
                        .charAt(0)
                        .toUpperCase()}
                </div>

                <div class="guardian-info">

                    <b>
                        ${guardian.name || "Guardian"}
                    </b>

                    <small>
                        ${guardian.relation || ""}
                        ·
                        ${phone}
                    </small>

                </div>

                <a
                    class="call-btn"
                    href="tel:+91${phone}"
                    title="Call guardian"
                >
                    ☎
                </a>

            `;


            container.appendChild(
                element
            );

        }
    );

}


// ======================================================
// SAVE PROFILE
// ======================================================

$("profileForm")?.addEventListener(
    "submit",
    async event => {

        event.preventDefault();


        const name =
            $("pname")
                .value
                .trim();


        const phone =
            $("pphone")
                .value
                .replace(
                    /\D/g,
                    ""
                );


        if (
            !name ||
            !/^[6-9]\d{9}$/.test(phone)
        ) {

            $("pmsg").textContent =
                "Enter a valid name and phone.";

            return;

        }


        await setDoc(
            doc(
                db,
                "users",
                currentUser.uid
            ),
            {

                name,

                email:
                    currentUser.email,

                phone

            },
            {
                merge: true
            }
        );


        localStorage.setItem(
            "safeher_name",
            name
        );


        localStorage.setItem(
            "safeher_phone",
            phone
        );


        $("name").textContent =
            name.split(" ")[0];


        $("pmsg").textContent =
            "✓ Profile saved successfully.";

    }
);


// ======================================================
// ADD GUARDIAN
// ======================================================

$("guardianForm")?.addEventListener(
    "submit",
    async event => {

        event.preventDefault();


        const name =
            $("gname")
                .value
                .trim();


        const relation =
            $("relation")
                .value
                .trim();


        const phone =
            $("gphone")
                .value
                .replace(
                    /\D/g,
                    ""
                );


        const email =
            $("gemail")
                .value
                .trim();


        if (
            !name ||
            !relation ||
            !/^[6-9]\d{9}$/.test(phone)
        ) {

            $("gmsg").textContent =
                "Enter valid guardian details.";

            return;

        }


        await addDoc(
            collection(
                db,
                "users",
                currentUser.uid,
                "guardians"
            ),
            {

                name,

                relation,

                phone,

                email,

                createdAt:
                    serverTimestamp()

            }
        );


        $("gmsg").textContent =
            "✓ Guardian added successfully.";


        event.target.reset();


        await loadGuardians();

    }
);


// ======================================================
// 🚨 REAL SOS
// ======================================================

async function startSOS() {

    const button =
        $("sos");


    const messageBox =
        $("sosMsg");


    try {

        // ----------------------------------------------
        // CONFIRMATION
        // ----------------------------------------------

        if (
            $("confirmSOS")?.checked
        ) {

            const confirmed =
                confirm(
                    "🚨 SAFEHER SOS\n\n" +
                    "Your current location will be shared " +
                    "with your emergency network.\n\n" +
                    "Continue?"
                );


            if (!confirmed) {
                return;
            }

        }


        messageBox.textContent =
            "Getting your current GPS location…";


        // ----------------------------------------------
        // GET GPS
        // ----------------------------------------------

        if (!currentLocation) {

            await new Promise(
                (resolve, reject) => {

                    navigator.geolocation
                        .getCurrentPosition(

                            position => {

                                currentLocation = {

                                    latitude:
                                        position.coords.latitude,

                                    longitude:
                                        position.coords.longitude,

                                    accuracy:
                                        position.coords.accuracy,

                                    speed:
                                        position.coords.speed

                                };

                                resolve();

                            },

                            () => {

                                reject(
                                    new Error(
                                        "Please allow GPS/location permission."
                                    )
                                );

                            },

                            {

                                enableHighAccuracy:
                                    true,

                                timeout:
                                    10000,

                                maximumAge:
                                    0

                            }

                        );

                }
            );

        }


        // ----------------------------------------------
        // PROFILE
        // ----------------------------------------------

        const userSnapshot =
            await getDoc(
                doc(
                    db,
                    "users",
                    currentUser.uid
                )
            );


        const profile =
            userSnapshot.exists()
                ? userSnapshot.data()
                : {};


        const name =
            profile.name ||
            localStorage.getItem(
                "safeher_name"
            ) ||
            "SafeHer User";


        const phone =
            profile.phone ||
            localStorage.getItem(
                "safeher_phone"
            ) ||
            "";


        // ----------------------------------------------
        // GUARDIANS
        // ----------------------------------------------

        const guardians =
            await getGuardians();


        messageBox.textContent =
            "Connecting to SafeHer emergency service…";


        // ----------------------------------------------
        // BACKEND
        // ----------------------------------------------

        const response =
            await fetch(
                `${API}/api/sos/start`,
                {

                    method: "POST",

                    headers: {

                        "Content-Type":
                            "application/json"

                    },

                    body:
                        JSON.stringify({

                            name,

                            phone,

                            latitude:
                                currentLocation.latitude,

                            longitude:
                                currentLocation.longitude,

                            guardians

                        })

                }
            );


        const data =
            await response.json();


        console.log(
            "SAFEHER SOS RESPONSE:",
            data
        );


        if (
            !response.ok ||
            !data.success
        ) {

            throw new Error(
                data.message ||
                "SOS could not be started."
            );

        }


        // ----------------------------------------------
        // SESSION ACTIVE
        // ----------------------------------------------

        activeSOS =
            data.sessionId;


        localStorage.setItem(
            "safeher_sos_session",
            activeSOS
        );


        // ----------------------------------------------
        // BUTTON
        // ----------------------------------------------

        button.innerHTML = `

            <span>
                END
            </span>

            <small>
                Stop emergency session
            </small>

        `;


        button.classList.add(
            "sos-active"
        );


        // ----------------------------------------------
        // MESSAGE
        // ----------------------------------------------

        messageBox.innerHTML = `

            <strong>
                🚨 SOS ACTIVE
            </strong>

            <br><br>

            Your live location is being shared.

            <br><br>

            <b>
                Session:
                ${activeSOS}
            </b>

            <br><br>

            <a
                href="${data.guardianUrl}"
                target="_blank"
            >
                👁 Open Guardian Live View →
            </a>

        `;


        console.log(
            "🚨 SAFEHER SOS ACTIVE:",
            activeSOS
        );


    } catch (error) {

        console.error(
            "SOS ERROR:",
            error
        );


        messageBox.textContent =
            `❌ ${error.message}`;

    }

}


// ======================================================
// END SOS
// ======================================================

async function endSOS() {

    if (!activeSOS) {
        return;
    }


    const confirmed =
        confirm(
            "End the active SafeHer emergency session?"
        );


    if (!confirmed) {
        return;
    }


    try {

        await fetch(
            `${API}/api/sos/end`,
            {

                method: "POST",

                headers: {

                    "Content-Type":
                        "application/json"

                },

                body:
                    JSON.stringify({

                        sessionId:
                            activeSOS

                    })

                }

        );

    } catch (error) {

        console.error(
            "END SOS:",
            error
        );

    }


    activeSOS =
        null;


    localStorage.removeItem(
        "safeher_sos_session"
    );


    $("sos").innerHTML = `

        <span>
            SOS
        </span>

        <small>
            Press for emergency
        </small>

    `;


    $("sos")
        .classList
        .remove("sos-active");


    $("sosMsg").textContent =
        "Emergency session ended. You are safe.";

}


// ======================================================
// SOS BUTTON
// ======================================================

// THERE IS ONLY ONE SOS LISTENER IN THIS FILE.

$("sos")?.addEventListener(
    "click",
    async () => {

        if (activeSOS) {

            await endSOS();

        } else {

            await startSOS();

        }

    }
);


// ======================================================
// SAFE ROUTE
// ======================================================

$("safeRoute")?.addEventListener(
    "click",
    async () => {

        if (!currentLocation) {

            alert(
                "Please allow GPS first."
            );

            return;

        }


        const destination =
            prompt(
                "Enter destination coordinates:\n\nlatitude,longitude\n\nExample:\n17.3850,78.4867"
            );


        if (!destination) {
            return;
        }


        const parts =
            destination
                .split(",")
                .map(Number);


        if (
            parts.length !== 2 ||
            parts.some(
                Number.isNaN
            )
        ) {

            alert(
                "Please use latitude,longitude format."
            );

            return;

        }


        try {

            const response =
                await fetch(
                    `${API}/api/route?` +
                    `fromLat=${currentLocation.latitude}` +
                    `&fromLng=${currentLocation.longitude}` +
                    `&toLat=${parts[0]}` +
                    `&toLng=${parts[1]}`
                );


            const data =
                await response.json();


            if (
                !response.ok ||
                !data.success
            ) {

                throw new Error(
                    data.message ||
                    "Route unavailable."
                );

            }


            if (routeLayer) {

                map.removeLayer(
                    routeLayer
                );

            }


            routeLayer =
                L.geoJSON(
                    data.geometry
                )
                .addTo(map);


            map.fitBounds(
                routeLayer.getBounds(),
                {
                    padding:
                        [30, 30]
                }
            );


            alert(
                `Route distance: ${data.distanceKm} km\n` +
                `Estimated time: ${data.durationMin} minutes`
            );


        } catch (error) {

            alert(
                `Route error: ${error.message}`
            );

        }

    }
);


// ======================================================
// AUDIO EVIDENCE
// ======================================================

$("startAudio")?.addEventListener(
    "click",
    async () => {

        try {

            if (
                audioRecorder &&
                audioRecorder.state === "recording"
            ) {

                audioRecorder.stop();

                return;

            }


            const stream =
                await navigator
                    .mediaDevices
                    .getUserMedia({
                        audio: true
                    });


            audioChunks = [];


            audioRecorder =
                new MediaRecorder(
                    stream
                );


            audioRecorder.ondataavailable =
                event => {

                    audioChunks.push(
                        event.data
                    );

                };


            audioRecorder.onstop =
                () => {

                    const blob =
                        new Blob(
                            audioChunks,
                            {
                                type:
                                    "audio/webm"
                            }
                        );


                    $("audioPreview").src =
                        URL.createObjectURL(
                            blob
                        );


                    $("audioPreview")
                        .style.display =
                        "block";


                    stream
                        .getTracks()
                        .forEach(
                            track =>
                                track.stop()
                        );


                    $("evidenceStatus")
                        .textContent =
                        "✓ Audio captured.";

                };


            audioRecorder.start();


            $("evidenceStatus")
                .textContent =
                "🔴 Recording… click again to stop.";

        } catch (error) {

            $("evidenceStatus")
                .textContent =
                `Microphone error: ${error.message}`;

        }

    }
);


// ======================================================
// CAMERA
// ======================================================

$("takePhoto")?.addEventListener(
    "click",
    async () => {

        try {

            cameraStream =
                await navigator
                    .mediaDevices
                    .getUserMedia({
                        video: true
                    });


            $("cameraPreview")
                .srcObject =
                cameraStream;


            $("cameraPreview")
                .style.display =
                "block";


            $("capturePhoto")
                .style.display =
                "block";


        } catch (error) {

            $("evidenceStatus")
                .textContent =
                `Camera error: ${error.message}`;

        }

    }
);


$("capturePhoto")?.addEventListener(
    "click",
    () => {

        const video =
            $("cameraPreview");


        const canvas =
            $("photoCanvas");


        canvas.width =
            video.videoWidth;


        canvas.height =
            video.videoHeight;


        canvas
            .getContext("2d")
            .drawImage(
                video,
                0,
                0
            );


        $("photoPreview")
            .src =
            canvas.toDataURL(
                "image/jpeg",
                0.9
            );


        $("photoPreview")
            .style.display =
            "block";


        $("evidenceStatus")
            .textContent =
            "✓ Photo captured.";

    }
);


// ======================================================
// AUTH
// ======================================================

onAuthStateChanged(
    auth,
    async user => {

        if (!user) {

            location.href =
                "../index.html";

            return;

        }


        if (!user.emailVerified) {

            location.href =
                "verify-email.html";

            return;

        }


        currentUser =
            user;


        const phoneVerified =
            localStorage.getItem(
                "safeher_phone_verified"
            );


        if (
            phoneVerified !== "true"
        ) {

            location.href =
                "verify-phone.html";

            return;

        }


        try {

            initMap();

            startTracking();

            await loadProfile();


            const savedSession =
                localStorage.getItem(
                    "safeher_sos_session"
                );


            if (savedSession) {

                console.log(
                    "Previous SOS session:",
                    savedSession
                );

            }

        } catch (error) {

            console.error(
                "Dashboard initialization:",
                error
            );

        }

    }
);