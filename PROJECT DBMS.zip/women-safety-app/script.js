/* =========================================================
   SAFEHER - MAIN LOGIN SCRIPT
========================================================= */


/* =========================================================
   ELEMENTS
========================================================= */

const hero =
    document.getElementById("hero");

const shield =
    document.getElementById("shield");

const energy =
    document.getElementById("energy");

const loginCard =
    document.getElementById("loginCard");

const password =
    document.getElementById("password");

const togglePassword =
    document.getElementById("togglePassword");

const loginForm =
    document.getElementById("loginForm");

const message =
    document.getElementById("message");

const loginBtn =
    document.getElementById("loginBtn");

const signup =
    document.getElementById("signup");

const forgot =
    document.getElementById("forgot");


/* =========================================================
   CREATE PARTICLES
========================================================= */

function createParticles() {

    const particleContainer =
        document.querySelector(".particles");

    if (!particleContainer) return;

    for (let i = 0; i < 90; i++) {

        const particle =
            document.createElement("span");

        particle.style.position =
            "absolute";

        particle.style.width =
            Math.random() * 4 + 1 + "px";

        particle.style.height =
            particle.style.width;

        particle.style.borderRadius =
            "50%";

        particle.style.background =
            i % 3 === 0
                ? "#ff3d7f"
                : "#ffffff";

        particle.style.left =
            Math.random() * 100 + "%";

        particle.style.top =
            Math.random() * 100 + "%";

        particle.style.opacity =
            Math.random() * .5;

        particle.style.boxShadow =
            "0 0 8px rgba(255,60,130,.7)";

        particle.style.animation =
            `floatParticle ${
                3 + Math.random() * 6
            }s ease-in-out infinite`;

        particle.style.animationDelay =
            Math.random() * 4 + "s";

        particleContainer.appendChild(
            particle
        );

    }

}


/* Particle animation */

const particleStyle =
    document.createElement("style");

particleStyle.innerHTML = `

@keyframes floatParticle {

    0%,100% {
        transform: translate(0,0);
        opacity: .15;
    }

    50% {
        transform: translate(
            20px,
            -30px
        );
        opacity: .8;
    }

}

`;

document.head.appendChild(
    particleStyle
);

createParticles();


/* =========================================================
   INTRO ANIMATION
========================================================= */

window.addEventListener(
    "load",
    () => {

        /* Shield */

        setTimeout(() => {

            if (!shield) return;

            shield.style.transform =
                "scale(1.15)";

            shield.style.filter =
                "drop-shadow(0 0 35px #ff3d7f)";

        }, 1200);


        /* Energy */

        setTimeout(() => {

            if (!energy) return;

            energy.classList.add(
                "explode"
            );

        }, 2200);


        /* Hide hero */

        setTimeout(() => {

            if (!hero) return;

            hero.classList.add(
                "hide"
            );

        }, 2500);


        /* Show login */

        setTimeout(() => {

            if (!loginCard) return;

            loginCard.classList.add(
                "show"
            );

        }, 3000);

    }
);


/* =========================================================
   PASSWORD VISIBILITY
========================================================= */

if (
    togglePassword &&
    password
) {

    togglePassword.addEventListener(
        "click",
        () => {

            if (
                password.type ===
                "password"
            ) {

                password.type =
                    "text";

                togglePassword.textContent =
                    "◌";

            } else {

                password.type =
                    "password";

                togglePassword.textContent =
                    "◉";

            }

        }
    );

}


/* =========================================================
   FIREBASE CONFIG
========================================================= */

const firebaseConfig = {

    apiKey:
        "AIzaSyCQ4WDiWr--x9xr2sigT2huMpNdyWR5Ors",

    authDomain:
        "safeher-40703.firebaseapp.com",

    projectId:
        "safeher-40703",

    storageBucket:
        "safeher-40703.firebasestorage.app",

    messagingSenderId:
        "1042565835984",

    appId:
        "1:1042565835984:web:91cef9cd03ef9989cfc2d5"

};


/* =========================================================
   FIREBASE MODULES
========================================================= */

let firebaseApp = null;
let auth = null;


/*
    Firebase is loaded only when needed.
    This prevents Firebase from breaking
    the SafeHer intro animation.
*/

async function initializeFirebase() {

    if (auth) {
        return auth;
    }


    const {
        initializeApp
    } =
        await import(
            "https://www.gstatic.com/firebasejs/12.9.0/firebase-app.js"
        );


    const {
        getAuth
    } =
        await import(
            "https://www.gstatic.com/firebasejs/12.9.0/firebase-auth.js"
        );


    firebaseApp =
        initializeApp(
            firebaseConfig
        );


    auth =
        getAuth(
            firebaseApp
        );


    return auth;

}


/* =========================================================
   LOGIN
========================================================= */

if (loginForm) {

    loginForm.addEventListener(
        "submit",
        async (event) => {

            event.preventDefault();


            const email =
                document
                    .getElementById("email")
                    .value
                    .trim();


            const passwordValue =
                password.value;


            if (
                !email ||
                !passwordValue
            ) {

                message.style.color =
                    "#ff6a9d";

                message.textContent =
                    "Please enter your email and password.";

                return;

            }


            /* Loading */

            loginBtn.disabled =
                true;

            loginBtn.querySelector(
                "span"
            ).textContent =
                "Authenticating...";


            message.style.color =
                "#8d93a2";

            message.textContent =
                "Signing you in securely...";


            try {

                /* Load Firebase */

                const firebaseAuth =
                    await initializeFirebase();


                const {
                    signInWithEmailAndPassword,
                    signOut
                } =
                    await import(
                        "https://www.gstatic.com/firebasejs/12.9.0/firebase-auth.js"
                    );


                /* Login */

                const userCredential =
                    await signInWithEmailAndPassword(
                        firebaseAuth,
                        email,
                        passwordValue
                    );


                const user =
                    userCredential.user;


                /* =================================================
                   EMAIL VERIFICATION
                ================================================= */

                if (
                    !user.emailVerified
                ) {

                    message.style.color =
                        "#ff6a9d";

                    message.textContent =
                        "Please verify your email before signing in.";

                    await signOut(
                        firebaseAuth
                    );

                    loginBtn.disabled =
                        false;

                    loginBtn.querySelector(
                        "span"
                    ).textContent =
                        "Sign in securely";

                    return;

                }


                /* Save email */

                localStorage.setItem(
                    "safeher_email",
                    user.email
                );


                /* Success */

                message.style.color =
                    "#55e6ae";

                message.textContent =
                    "Login successful!";


                /* Go Home */

                setTimeout(
                    () => {

                        window.location.href =
                            "pages/home.html";

                    },
                    700
                );


            }


            catch (error) {

                console.error(
                    "Firebase login error:",
                    error
                );


                message.style.color =
                    "#ff6a9d";


                if (
                    error.code ===
                    "auth/invalid-credential"
                ) {

                    message.textContent =
                        "Incorrect email or password.";

                }

                else if (
                    error.code ===
                    "auth/user-not-found"
                ) {

                    message.textContent =
                        "No account found with this email.";

                }

                else if (
                    error.code ===
                    "auth/wrong-password"
                ) {

                    message.textContent =
                        "Incorrect password.";

                }

                else if (
                    error.code ===
                    "auth/invalid-email"
                ) {

                    message.textContent =
                        "Please enter a valid email address.";

                }

                else {

                    message.textContent =
                        "Login failed. Please try again.";

                }


                loginBtn.disabled =
                    false;

                loginBtn.querySelector(
                    "span"
                ).textContent =
                    "Sign in securely";

            }

        }
    );

}


/* =========================================================
   FORGOT PASSWORD
========================================================= */

if (forgot) {

    forgot.addEventListener(
        "click",
        async () => {

            const email =
                document
                    .getElementById("email")
                    .value
                    .trim();


            if (!email) {

                message.style.color =
                    "#ff6a9d";

                message.textContent =
                    "Enter your email first.";

                document
                    .getElementById("email")
                    .focus();

                return;

            }


            try {

                message.style.color =
                    "#8d93a2";

                message.textContent =
                    "Sending password reset email...";


                const firebaseAuth =
                    await initializeFirebase();


                const {
                    sendPasswordResetEmail
                } =
                    await import(
                        "https://www.gstatic.com/firebasejs/12.9.0/firebase-auth.js"
                    );


                await sendPasswordResetEmail(
                    firebaseAuth,
                    email
                );


                message.style.color =
                    "#55e6ae";

                message.textContent =
                    "Password reset email sent. Check your inbox.";

            }


            catch (error) {

                console.error(
                    "Reset error:",
                    error
                );


                message.style.color =
                    "#ff6a9d";

                message.textContent =
                    "Unable to send password reset email.";

            }

        }
    );

}


/* =========================================================
   CREATE ACCOUNT
========================================================= */

if (signup) {

    signup.addEventListener(
        "click",
        () => {

            window.location.href =
                "pages/register.html";

        }
    );

}